function res = f(x,A)
  res = x^2 - A;
endfunction
